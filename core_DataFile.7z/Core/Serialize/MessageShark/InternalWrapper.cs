﻿using System;
using System.Collections.Generic;

using System.Text;
using System.Collections;

namespace System.Binary {
    public class InternalWrapper<T> {
        public T Value { get; set; }
    }
}
